const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector("#main-nav");
const searchButton = document.querySelector(".search-toggle");
const searchPanel = document.querySelector("#search-panel");
const searchInput = document.querySelector("#site-search-input");

function setMenuOpen(isOpen) {
  if (!menuButton || !navigation) return;
  if (isOpen) setSearchOpen(false);
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Fechar menu" : "Abrir menu");
  navigation.classList.toggle("is-open", isOpen);
}

function setSearchOpen(isOpen) {
  if (!searchButton || !searchPanel) return;
  searchButton.setAttribute("aria-expanded", String(isOpen));
  searchButton.setAttribute("aria-label", isOpen ? "Fechar busca no site" : "Abrir busca no site");
  searchPanel.classList.toggle("is-open", isOpen);
  if (isOpen) {
    setMenuOpen(false);
    searchInput?.focus();
  }
}

menuButton?.addEventListener("click", () => {
  setMenuOpen(menuButton.getAttribute("aria-expanded") !== "true");
});

navigation?.addEventListener("click", (event) => {
  if (event.target.closest("a")) setMenuOpen(false);
});

searchButton?.addEventListener("click", () => {
  setSearchOpen(searchButton.getAttribute("aria-expanded") !== "true");
});

document.querySelector(".mobile-menu-trigger")?.addEventListener("click", () => {
  setMenuOpen(menuButton?.getAttribute("aria-expanded") !== "true");
});

document.querySelector(".mobile-search-trigger")?.addEventListener("click", () => {
  setSearchOpen(true);
});

document.querySelector("#site-search-form")?.addEventListener("submit", (event) => {
  event.preventDefault();
  const query = searchInput.value.trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
  const sections = [...document.querySelectorAll("main section")];
  const match = sections.find((section) => section.textContent.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").includes(query));
  const feedback = document.querySelector("#search-feedback");
  if (match) {
    feedback.textContent = `Encontramos conteúdo relacionado a “${searchInput.value.trim()}”.`;
    match.scrollIntoView({ behavior: "smooth", block: "start" });
    setSearchOpen(false);
  } else {
    feedback.textContent = "Não encontramos esse termo nesta página. Tente buscar por produto, dimensões, história ou contato.";
  }
});

document.querySelector("#newsletter-form")?.addEventListener("submit", (event) => {
  event.preventDefault();
  const email = document.querySelector("#newsletter-email").value.trim();
  const subject = encodeURIComponent("Solicitação de novidades Fort Domus");
  const body = encodeURIComponent(`Olá! Gostaria de receber novidades e informações da Fort Domus.\n\nMeu e-mail: ${email}`);
  document.querySelector("#newsletter-feedback").textContent = "Abrindo seu aplicativo de e-mail. Envie a mensagem para concluir sua solicitação.";
  window.location.href = `mailto:fortdomus@gmail.com?subject=${subject}&body=${body}`;
});

const currentYear = document.querySelector("#current-year");
if (currentYear) currentYear.textContent = new Date().getFullYear();

const lightbox = document.querySelector("#gallery-lightbox");
if (lightbox) {
  const lightboxImage = lightbox.querySelector(".lightbox-image");
  const lightboxCount = lightbox.querySelector(".lightbox-count");
  const lightboxButtons = [...lightbox.querySelectorAll("[data-lightbox-action='previous'], [data-lightbox-action='next']")];
  let galleryImages = [];
  let activeImageIndex = 0;
  let lastGalleryTrigger = null;

  function showGalleryImage(index) {
    activeImageIndex = (index + galleryImages.length) % galleryImages.length;
    const image = galleryImages[activeImageIndex];
    lightboxImage.src = image.currentSrc || image.src;
    lightboxImage.alt = image.alt;
    lightboxCount.textContent = `${activeImageIndex + 1} / ${galleryImages.length}`;
    lightboxButtons.forEach((button) => {
      button.disabled = galleryImages.length < 2;
    });
  }

  document.addEventListener("click", (event) => {
    const trigger = event.target.closest("[data-gallery]");
    if (!trigger || !lightbox) return;
    event.preventDefault();
    galleryImages = [...new Map([...document.querySelectorAll("[data-gallery] img")].map((image) => [image.currentSrc || image.src, image])).values()];
    const selectedImage = trigger.querySelector("img");
    const selectedImageSrc = selectedImage.currentSrc || selectedImage.src;
    activeImageIndex = galleryImages.findIndex((image) => (image.currentSrc || image.src) === selectedImageSrc);
    if (activeImageIndex < 0) return;
    lastGalleryTrigger = trigger;
    showGalleryImage(activeImageIndex);
    lightbox.showModal();
  });

  lightbox.querySelector("[data-lightbox-action='close']")?.addEventListener("click", () => lightbox.close());
  lightbox.querySelector("[data-lightbox-action='previous']")?.addEventListener("click", () => showGalleryImage(activeImageIndex - 1));
  lightbox.querySelector("[data-lightbox-action='next']")?.addEventListener("click", () => showGalleryImage(activeImageIndex + 1));
  lightbox.addEventListener("click", (event) => {
    if (event.target === lightbox) lightbox.close();
  });
  lightbox.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft" && galleryImages.length > 1) showGalleryImage(activeImageIndex - 1);
    if (event.key === "ArrowRight" && galleryImages.length > 1) showGalleryImage(activeImageIndex + 1);
  });
  lightbox.addEventListener("close", () => lastGalleryTrigger?.focus());
}

if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll("[data-reveal]").forEach((element) => revealObserver.observe(element));
} else {
  document.querySelectorAll("[data-reveal]").forEach((element) => element.classList.add("is-visible"));
}
